package com.example.unit_converter

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var inputUnitSpinner: Spinner
    private lateinit var outputUnitSpinner: Spinner
    private lateinit var inputEditText: EditText
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputUnitSpinner = findViewById(R.id.spinnerInputUnit)
        outputUnitSpinner = findViewById(R.id.spinnerOutputUnit)
        inputEditText = findViewById(R.id.editTextInput)
        resultTextView = findViewById(R.id.textViewResult)
        val convertButton: Button = findViewById(R.id.buttonConvert)

        // Populate spinners with unit options
        val unitOptions = arrayOf("Meter", "Kilometer", "Centimeter", "Millimeter")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, unitOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        inputUnitSpinner.adapter = adapter
        outputUnitSpinner.adapter = adapter

        inputUnitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        outputUnitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        convertButton.setOnClickListener {
            convertUnits()
        }
    }

    private fun convertUnits() {
        val inputValue = inputEditText.text.toString().toDoubleOrNull()

        if (inputValue != null) {
            val inputUnit = inputUnitSpinner.selectedItem.toString()
            val outputUnit = outputUnitSpinner.selectedItem.toString()

            val result = when (Pair(inputUnit, outputUnit)) {
                Pair("Meter", "Kilometer") -> inputValue / 1000
                Pair("Meter", "Centimeter") -> inputValue * 100
                Pair("Meter", "Millimeter") -> inputValue * 1000
                Pair("Kilometer", "Meter") -> inputValue * 1000
                Pair("Kilometer", "Centimeter") -> inputValue * 100000
                Pair("Kilometer", "Millimeter") -> inputValue * 1e+6
                Pair("Centimeter", "Meter") -> inputValue / 100
                Pair("Centimeter", "Kilometer") -> inputValue / 100000
                Pair("Centimeter", "Millimeter") -> inputValue * 10
                Pair("Millimeter", "Meter") -> inputValue / 1000
                Pair("Millimeter", "Kilometer") -> inputValue / 1e+6
                Pair("Millimeter", "Centimeter") -> inputValue / 10
                else -> inputValue
            }

            resultTextView.text = "Result: $result $outputUnit"
        } else {
            resultTextView.text = "Result: Enter a valid value"
        }
    }
}